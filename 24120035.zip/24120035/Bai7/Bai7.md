```mermaid
stateDiagram-v2
    [*] --> Idle: Bắt đầu
    
    Idle --> Searching: StartSearch
    
    Searching --> PendingPayment: SelectHotel
    Searching --> Cancelled: Cancel
    
    PendingPayment --> Confirmed: PaySuccess
    PendingPayment --> Cancelled: PayTimeout / Cancel
    
    Confirmed --> [*]: Kết thúc
    Cancelled --> [*]: Kết thúc
```