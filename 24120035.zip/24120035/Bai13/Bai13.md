```mermaid
journey
    title Hành trình đặt tour trên Smart Travel App
    section Nhận biết
      Thấy quảng cáo tour trên FB/TikTok: 5: User
      Tò mò về điểm đến: 4: User
    section Khám phá
      Truy cập Smart Travel: 3: User
      Xem chi tiết lịch trình các tour: 5: User
    section Quyết định
      So sánh giá cả và dịch vụ: 3: User
      Chọn được tour ưng ý: 5: User
    section Hành động
      Điền thông tin đặt tour: 4: User
      Thanh toán trực tuyến: 2: User
    section Sau chuyến đi
      Nhận email cảm ơn: 4: User
      Xem gợi ý cho chuyến đi tới: 5: User
```