```mermaid
sequenceDiagram
    autonumber
    actor User as User
    participant TS as TravelSystem
    participant DB as HotelDatabase
    participant PS as PaymentService

    User->>TS: Nhập thông tin tìm kiếm (điểm đến, ngày lưu trú)
    TS->>DB: Gửi truy vấn danh sách khách sạn phù hợp
    DB-->>TS: Trả về danh sách khách sạn
    TS-->>User: Hiển thị danh sách khách sạn
    
    User->>TS: Chọn khách sạn & Xác nhận đặt phòng
    TS->>PS: Gửi yêu cầu xác nhận thanh toán
    PS-->>TS: Thanh toán thành công
    
    TS-->>User: Gửi thông báo đặt phòng thành công
```