```mermaid
flowchart TD
    A([Bắt đầu]) --> B[/Nhập điểm khởi hành, điểm đến, ngân sách tối đa/]
    B --> C[Truy xuất danh sách các gói du lịch có sẵn]
    C --> D{Có gói phù hợp?\n'Giá <= Ngân sách'}
    
    D -- Có --> E[/Hiển thị danh sách gói gợi ý/]
    D -- Không --> F{Người dùng muốn làm gì?}
    
    F -- Tăng ngân sách --> B
    F -- Chọn điểm đến khác --> B
    
    E --> G([Kết thúc])
```