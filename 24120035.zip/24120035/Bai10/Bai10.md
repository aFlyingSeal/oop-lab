```mermaid
flowchart TD
    %% Định nghĩa các lớp
    subgraph Presentation_Layer [Presentation Layer - Frontend]
        Browser["🌐 Browser (User Interface)"]
    end

    subgraph Application_Layer [Application Layer - Backend]
        WebServer["🖥️ Web Server (Nginx / API Gateway)"]
        AppServer["⚙️ Application Server (Node.js/.NET/Spring Boot)"]
    end

    subgraph Data_Layer [Data Layer - Storage]
        DB[("🗄️ Database (PostgreSQL / MongoDB)")]
    end

    %% Luồng dữ liệu và chú thích
    User((User)) -->|HTTP Request / HTML| Browser
    
    Browser -->|REST API Request / JSON| WebServer
    WebServer -->|Forward Request| AppServer
    
    AppServer -->|SQL Query / NoSQL Command| DB
    DB -.->|Data Result / Recordset| AppServer
    
    AppServer -.->|JSON Response| WebServer
    WebServer -.->|HTTP Response / JSON| Browser
```